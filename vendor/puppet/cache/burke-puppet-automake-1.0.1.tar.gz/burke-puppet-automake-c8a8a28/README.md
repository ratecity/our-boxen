# automake Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include automake
```

## Required Puppet Modules

* boxen
* homebrew

